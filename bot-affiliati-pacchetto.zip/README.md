# bot-affiliati

Bot Telegram automatico per offerte Amazon

## Funzionalità
- Pubblica automaticamente messaggi in più canali Telegram
- Comandi: /start e /pubblica

## Variabili d'ambiente richieste
- `BOT_TOKEN`

## Deploy su Railway
1. Carica questo repo su GitHub
2. Vai su [Railway](https://railway.app)
3. Crea un nuovo progetto da GitHub (Deploy from GitHub repo)
4. Aggiungi `BOT_TOKEN` nelle variabili d’ambiente

